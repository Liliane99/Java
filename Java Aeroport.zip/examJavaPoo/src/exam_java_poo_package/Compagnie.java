package exam_java_poo_package;
// creation de l'enumeration : 
public enum Compagnie {
	FR("Air France"),
	MAROC("Royal Air Maroc"),
	QatarAirways("Quatar Airways") ;
	
	Compagnie(String compagnie){
		this.compagnie = compagnie ;
	}
	
	private String compagnie ;
	public String getCompagnie() {
		return this.compagnie ;
	}
}
