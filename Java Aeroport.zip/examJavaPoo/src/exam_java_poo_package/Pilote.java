package exam_java_poo_package;

public class Pilote extends Personne implements IDecolage{
	private double nombre_heures_vol;
	public double nombreVolTotal;
	
	
	//Les constructeurs : 
	public Pilote(String n, String p, double nombre_heures_vol, double nombreVolTotal) {
		super(n, p);
		this.nombre_heures_vol = nombre_heures_vol;
		this.nombreVolTotal = nombreVolTotal;
		
	}
	
	//Les getters et les setters : 
	
	
	public String getNom(){return super.getNom();}
	public void setNom(String n){super.setNom(n);}
	
	public String getPrenom(){return super.getPrenom();}
	public void setPrenom(String p){super.setPrenom(p);}
	
	public double getNombre_heures_vol(){return nombre_heures_vol;}
	public void setNombre_heures_vol(double nombre_heures_vol){this.nombre_heures_vol = nombre_heures_vol;}
	
	public double getNombreVolTotal(){return nombreVolTotal;}
	
	public String toString() {
		return "Le pilote " + this.getNom() + " " 
	+ this.getPrenom() +  " a " + this.getNombre_heures_vol() 
	+ " heures de vol" ;
	}
	
	// Question F : Red�finition de la m�thode voler
	public void voler(double nbHeures) {
		nombreVolTotal = this.nombre_heures_vol + nbHeures; 
		System.out.println("Le pilote " + super.getNom() +" "+ super.getPrenom() +" " + "posss�de" +" "+ this.nombreVolTotal +" "+ "heures.");
		
	}
	
	
}
