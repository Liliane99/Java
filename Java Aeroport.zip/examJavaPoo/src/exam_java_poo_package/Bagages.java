package exam_java_poo_package;

public class Bagages implements IEmbarquement  {
	private String numero;
	private double poidsMaxAutorise;
	private double poidsActuel;
	
	
	public Bagages(String numero, double poidsMaxAutorise, double poidsActuel) {
		this.numero = numero;
		this.poidsMaxAutorise = poidsMaxAutorise;
		this.poidsActuel = poidsActuel;
		
	}
	
	//Les getters et les setters : 
	public String getNumero(){return this.numero;}
	public void setNumero(String numero){this.numero = numero;}
	
	public double getPoidsMaxAutorise(){return poidsMaxAutorise;}
	public void setPoidsMaxAutorise(double poidsMaxAutorise){this.poidsMaxAutorise = poidsMaxAutorise;}
	
	public double getPoidsActuel(){return poidsActuel;}
	public void setPoidsActuel(double poidsActuel){this.poidsActuel = poidsActuel;}
	
	public String toString() {
		return "Le bagage " + this.numero + " p�se " + this.poidsActuel ;
	}
	//Red�finir la m�thode :
	public void embarquer() {
		this.poidsMaxAutorise = 23;
		if (this.poidsActuel <= this.poidsMaxAutorise) {
			System.out.println("Poids OK !");
		} else if (this.poidsActuel > this.poidsMaxAutorise) {
			System.out.println(" Embarquement imposssible! Diminuer le Poids du bagage");
		}
	}
	
}
