package exam_java_poo_package;

public abstract class Vehicule {
    private String marque;
    
    public Vehicule(String m) {
        this.marque = m;
    }
    public String getMarque(){return this.marque;}
    public void setMarque(String m){this.marque = m;}
}