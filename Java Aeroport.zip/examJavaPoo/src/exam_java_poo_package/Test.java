package exam_java_poo_package;



public class Test {

	public static void main(String[] args) {
		// creation du vol :
		Vol vol = new Vol("QC102", "13/01/2021", "19/01/2021", "Paris", "Duba�") ;
		
		// Creation du pilote:
		Pilote pilote = new Pilote("Henry", "Olivier", 10000, 7) ;
		
		// creation du commandant de bord:
		CommandantDeBord commandantDeBord = new CommandantDeBord("Gomes", "Pierre", 30000,7, "MC102") ;
		
		// creation de l' avion		:
		Avion avion = new Avion("AirBus", 26000, 26000, Compagnie.QatarAirways ,  pilote, commandantDeBord, vol) ;
		
		// creation des voyageurs :
		Bagages bagage1 = new Bagages("BG100",23,20) ;
		Bagages bagage2 = new Bagages("CI200",23,10) ;
		Bagages BagagesVoyageur1 [] = {bagage1, bagage2} ;
		
		Voyageur Voyageur1 = new Voyageur("SAM", "Samir", BagagesVoyageur1, vol) ;
		
		Bagages bagage3 = new Bagages("AI300",23,23) ;
		Bagages bagage4 = new Bagages("SX400",15,15) ;
		Bagages BagagesVoyageur2 [] = {bagage3, bagage4} ;
		
		Voyageur Voyageur2 = new Voyageur("SOW", "Ary", BagagesVoyageur2, vol) ;
		
		
		//  R�sultat : 
		
		//Titre : 
		System.out.println("                        Application de gestion d'a�roport :"        );
		// Question k affichage des informations des avions et des pilotes : 
		System.out.println("               ");
		System.out.println(avion.toString()) ; 
		System.out.println(pilote.toString());
		System.out.println(commandantDeBord.toString());
		System.out.println("             ");
		// Question j : les information du Vol : 
		System.out.println(vol.toString()) ; 
		System.out.println("             ");
		// Quetion l : affichage des informations des voyageurs et de leurs bagages : 
		System.out.println("Listes des voyageurs :");
		System.out.println("             ");
		System.out.println(Voyageur1.toString()) ;
		System.out.println(bagage1.toString());
		System.out.println(bagage2.toString());
		System.out.println("             ");
		System.out.println(Voyageur2.toString()) ;
		System.out.println(bagage3.toString());
		System.out.println(bagage4.toString());
		System.out.println("            ");
		//V�rification du poids grace � la m�thode embarquer() : 
		System.out.println("V�rification du poids des bagages avant emabrquement ! ");
		System.out.println("             ");
		System.out.println("Bagage 1 du voyageur SAM SAMIR");
		bagage1.embarquer();
		System.out.println("Bagage 2 du voyageur SAM SAMIR");
		bagage2.embarquer();
		System.out.println("             ");
		System.out.println("Bagage 1 du voyageur SOW ARY");
		bagage3.embarquer();
		System.out.println("Bagage 2 du voyageur SOW ARY");
		bagage4.embarquer();
		System.out.println("            ");
		//Question  m : 
		System.out.println("Capacit� de K�rosene restante dans l'avion apr�s le vol de 7h Paris-Duba� :");
		avion.voler(7) ;
		System.out.println("            ");
		System.out.println("Le nombre d'heure total du pilote et du commandant de bord apr�s le vol de Paris-Duba� :");
		pilote.voler(7) ;
		commandantDeBord.voler(7);
		
		
	}

}
	
	
	
