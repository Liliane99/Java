package exam_java_poo_package;

public interface IEmbarquement {
	public void embarquer();
}
