package exam_java_poo_package;


public class Voyageur extends Personne{
	private Bagages [] bagages;
	private Vol vol;
	//le constructeur : 
	public Voyageur(String n , String p, Bagages [] bag, Vol vol) {
		super(n, p);
		this.bagages = bag;
		this.vol = vol;
	}

	//Les getters et les setters : 
	public Bagages[] getBagages(){return bagages;}
	public void setBagages(Bagages[] bag){this.bagages = bag;}
	
	public Vol getVol() {return vol;}
	public void setVol(Vol vol) {this.vol = vol;}
	
	
	public String toString() {
    	return "Le voyageur " + this.getNom() + " " + this.getPrenom() 
    	+ " prend le vol " + this.getVol().getNumero_vol() 
    	+ ". Il a " + this.bagages.length + " bagages : " ;
    }
}
