package exam_java_poo_package;

public class CommandantDeBord extends Pilote implements IDecolage{
	String matricule;
	
	
	//Les constructeurs : 
	public CommandantDeBord(String n, String p, double nombre_heures_vol, double nombreVolTotal, String matricule) {
		super(n, p, nombre_heures_vol, nombreVolTotal);
		this.matricule = matricule;
	}
	
	//Les getters et les setters : 
	public String getMatricule(){return matricule;}
	public void setMatricule(String matricule){this.matricule = matricule;}
	
	public double getNombreVolTotal(){return nombreVolTotal;}
	public void setNombreVolTotal(double nombreVolTotal){this.nombreVolTotal = nombreVolTotal;}
	
	//Question f : Red�finition de la m�thode voler
	public void voler(double nbHeures) {super.voler(nbHeures);};
	
	public String toString() {
		return "Le commandant de bord " + this.getNom() + " " 
	+ this.getPrenom() + ", de matricule "
	+ this.getMatricule() +  " a " + this.getNombre_heures_vol() 
	+ " heures de vol" ;
	}
	
	
	
}

