package exam_java_poo_package;

//Cr�ation de la class Avion fille de v�hicule (Gr�ce � Extends)
public class Avion extends Vehicule implements IDecolage{ //Ajout de "implements" qui permet de ramener l'interface IDecolage
	public double capaciteMaxKer;
	public double capaciteActuelleKer;
	private Compagnie compagnie;
	// navigation de r�f�rence
	private Pilote pilote; 
	private CommandantDeBord commandantDeBord;
	private Vol vol;
	
	//Les constructeurs :
	public Avion(String m) {
		super(m);
	}
	public Avion(String m, double capaciteMaxKer, double capaciteActuelleKer, Compagnie compagnie, Pilote pilote,
			CommandantDeBord commandantDeBord, Vol vol) {
		super(m);
		this.capaciteMaxKer = capaciteMaxKer;
		this.capaciteActuelleKer = capaciteActuelleKer;
		this.compagnie = compagnie;
		this.pilote = pilote;
		this.commandantDeBord = commandantDeBord;
		this.vol = vol;
	}
	
	//Les getters et les setters : 
	
	public Compagnie getCompagnie(){return compagnie;}
	public void setCompagnie(Compagnie compagnie){this.compagnie = compagnie;
	}
	public double getCapaciteMaxKer(){return capaciteMaxKer;}
	public void setCapaciteMaxKer(double capaciteMaxKer){this.capaciteMaxKer = capaciteMaxKer;}
	
	public double getCapaciteActuelleKer(){return capaciteActuelleKer;}
	public void setCapaciteActuelleKer(double capaciteActuelleKer){this.capaciteActuelleKer = capaciteActuelleKer;}
	
	public Pilote getPilote(){return pilote;}
	public void setPilote(Pilote pilote){this.pilote = pilote;}
	
	public CommandantDeBord getCommandantDeBord(){return commandantDeBord;}
	public void setCommandantDeBord(CommandantDeBord commandantDeBord){this.commandantDeBord = commandantDeBord;}
	
	public Vol getVol(){return vol;}
	public void setVol(Vol vol) {this.vol = vol;}
	
	//Afin d'afficher :
	public String toString() {
		return "L'avion de la compagnie " + this.getCompagnie() + " est de marque" +" "+ super.getMarque() +
		 " poss�de une capacit� maximale de " + this.getCapaciteMaxKer() +"l"+ ". Celui ci prends le vol " + this.getVol().getNumero_vol() + " pilot� par le pilote " 
		 + this.getPilote().getNom()+" "+ this.getPilote().getPrenom() +"qui poss�de " + " accompagn� du commandant de bord " + this.getCommandantDeBord().getNom() +" "+ this.getCommandantDeBord().getPrenom()  ;
	}
	
	//Red�finition de la m�thode voler() et mise � jour de la donn�e r�serve:
	 public void voler(double nbHeures) {
		double reserve = this.capaciteActuelleKer - 1300*nbHeures ; 
		System.out.println(reserve);
	}
	
}

