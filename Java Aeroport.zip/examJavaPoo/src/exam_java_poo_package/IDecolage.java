package exam_java_poo_package;

public interface IDecolage {
	abstract void voler(double nbHeures);
}
