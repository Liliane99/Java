package exam_java_poo_package;


public class Vol {
	private String numero_vol;
	private String date_depart;
	private String date_arrivee;
	private String ville_depart;
	private String ville_arrivee;
	
	//Les constructeurs : 
	public Vol(String numero_vol, String date_depart, String date_arrivee, String ville_depart, String ville_arrivee) {
		this.numero_vol = numero_vol;
		this.date_depart = date_depart;
		this.date_arrivee = date_arrivee;
		this.ville_depart = ville_depart;
		this.ville_arrivee = ville_arrivee;
	}
	

	//Les getters et les setters :  
	public String getNumero_vol(){return this.numero_vol;}
	public String getDate_depart(){return this.date_depart ;}
	public String date_arrivee() {return this.date_arrivee ;}
	public String getVille_depart() {return this.ville_depart ;}
	public String getVille_arrivee() {return this.ville_arrivee ;}
	
	
	public void setNumero_vol(String numero_vol) {this.numero_vol = numero_vol ;}
	public void setDate_depart(String date_depart) {this.date_depart = date_depart ;}
	
	// m�thodes.
	public String toString() {
		return "Le vol " + this.numero_vol + " part de " + this.ville_depart 
				+ " le " + this.date_depart + " � destination de " 
				+ this.ville_arrivee + " la date de retours est pr�vu pour le " + this.date_arrivee ;
	}
	
	
}
